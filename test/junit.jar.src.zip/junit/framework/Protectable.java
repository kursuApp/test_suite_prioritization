package junit.framework;

public interface Protectable {
  void protect() throws Throwable;
}
