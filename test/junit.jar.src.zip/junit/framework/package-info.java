package junit.framework;

interface package-info {}
