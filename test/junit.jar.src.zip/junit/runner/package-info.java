package junit.runner;

interface package-info {}
