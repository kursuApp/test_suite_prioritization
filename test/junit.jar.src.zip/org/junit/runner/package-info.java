package org.junit.runner;

interface package-info {}
