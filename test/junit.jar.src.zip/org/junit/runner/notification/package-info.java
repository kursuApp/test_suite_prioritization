package org.junit.runner.notification;

interface package-info {}
