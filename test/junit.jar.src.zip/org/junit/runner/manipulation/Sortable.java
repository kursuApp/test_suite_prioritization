package org.junit.runner.manipulation;

public interface Sortable {
  void sort(Sorter paramSorter);
}
