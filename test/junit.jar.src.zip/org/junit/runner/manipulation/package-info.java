package org.junit.runner.manipulation;

interface package-info {}
