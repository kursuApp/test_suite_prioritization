package org.junit.runner.manipulation;

public class NoTestsRemainException extends Exception {
  private static final long serialVersionUID = 1L;
}
