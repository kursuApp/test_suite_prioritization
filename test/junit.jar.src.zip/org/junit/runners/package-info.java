package org.junit.runners;

interface package-info {}
