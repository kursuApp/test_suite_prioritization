package org.junit.runners.model;

public abstract class Statement {
  public abstract void evaluate() throws Throwable;
}
