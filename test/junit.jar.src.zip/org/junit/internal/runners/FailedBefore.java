package org.junit.internal.runners;

@Deprecated
class FailedBefore extends Exception {
  private static final long serialVersionUID = 1L;
}
