package org.junit.internal.runners;

interface package-info {}
