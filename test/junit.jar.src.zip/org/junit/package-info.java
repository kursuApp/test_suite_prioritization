package org.junit;

interface package-info {}
